# Layer Visibility Toggle

**Author:** MD Nahid Amin  
**License:** GPL-2.0-or-later  
**Version:** 1.0.0

A QGIS dock-panel tool for toggling map-canvas layer visibility with the Spacebar.

## Features

- **Hide selected layer:** hide the chosen layer, then press Space again to restore its previous visibility.
- **Hide unselected layers:** keep the chosen layer visible and hide the others; press Space again to restore their previous visibility.
- **Hide multiple layers:** hide the checked layers and restore their previous visibility with the next Space press.
- **Turn Plugin OFF:** stop handling Spacebar and restore visibility if the plugin currently has layers hidden.
- Layer lists refresh when project layers are added or removed.

## Installation

1. Download the ZIP package from the [Releases](https://github.com/mdnahidamin/Layer-Visibility-Toggle/releases) page, or use **Plugins → Manage and Install Plugins → Install from ZIP**.
2. Select the downloaded ZIP.
3. Open **Layer Visibility Toggle** from the Plugins menu or toolbar.
4. Choose a mode and layer(s), then click **OK · Activate Spacebar**.
5. Give keyboard focus to the map canvas and press **Space** to toggle visibility.

## Requirements

- QGIS 3.0 or later (PyQt5-based QGIS builds).
- No additional Python packages.

## Notes

The Spacebar shortcut is handled only while the map canvas has keyboard focus, to avoid interfering with text fields and other controls. Please report compatibility issues through the [GitHub issue tracker](https://github.com/mdnahidamin/Layer-Visibility-Toggle/issues).

## License

This project is licensed under the GNU General Public License, version 2 or (at your option) any later version. See [LICENSE](LICENSE).
