from qgis.PyQt.QtCore import Qt, QObject, QEvent
from qgis.PyQt.QtWidgets import (
    QAction, QDockWidget, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QComboBox, QPushButton, QListWidget, QListWidgetItem, QStackedWidget,
    QFrame, QApplication, QLineEdit, QTextEdit, QPlainTextEdit,
    QAbstractSpinBox, QAbstractButton
)
from qgis.core import QgsProject


class LayerVisibilityToggle:
    MODES = ("Hide selected layer", "Hide unselected layers", "Hide multiple layers")

    def __init__(self, iface):
        self.iface = iface
        self.project = QgsProject.instance()
        self.action = None
        self.dock = None
        self.event_filter = None
        self.armed = False
        self.hidden = False
        self.saved_visibility = {}
        self.target_ids = set()
        self._building = False

    def initGui(self):
        self.action = QAction("Layer Visibility Toggle", self.iface.mainWindow())
        self.action.triggered.connect(self.show_panel)
        self.iface.addPluginToMenu("&Layer Visibility Toggle", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        self._deactivate(restore=True)
        if self.dock:
            self.iface.removeDockWidget(self.dock)
            self.dock.deleteLater()
            self.dock = None
        if self.action:
            self.iface.removePluginMenu("&Layer Visibility Toggle", self.action)
            self.iface.removeToolBarIcon(self.action)
            self.action = None

    def show_panel(self):
        if self.dock is None:
            self._build_panel()
        self.dock.show()
        self.dock.raise_()
        self.refresh_layers()

    def _build_panel(self):
        self.dock = QDockWidget("Layer Visibility Toggle", self.iface.mainWindow())
        self.dock.setObjectName("LayerVisibilityToggleDock")
        self.dock.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        root = QWidget()
        root.setObjectName("lvtRoot")
        layout = QVBoxLayout(root)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(12)

        heading = QLabel("Layer Visibility")
        heading.setObjectName("heading")
        subtitle = QLabel("Choose layers, then press SPACE to toggle visibility.")
        subtitle.setObjectName("subtitle")
        subtitle.setWordWrap(True)
        layout.addWidget(heading)
        layout.addWidget(subtitle)

        mode_label = QLabel("VISIBILITY MODE")
        mode_label.setObjectName("sectionLabel")
        layout.addWidget(mode_label)
        self.mode_combo = QComboBox()
        self.mode_combo.addItems(self.MODES)
        self.mode_combo.currentIndexChanged.connect(self._mode_changed)
        layout.addWidget(self.mode_combo)

        self.stack = QStackedWidget()
        self.single_page = QWidget()
        single_layout = QVBoxLayout(self.single_page)
        single_layout.setContentsMargins(0, 4, 0, 0)
        single_layout.setSpacing(7)
        single_layout.addWidget(QLabel("Select one layer"))
        self.single_combo = QComboBox()
        single_layout.addWidget(self.single_combo)
        self.stack.addWidget(self.single_page)

        self.multi_page = QWidget()
        multi_layout = QVBoxLayout(self.multi_page)
        multi_layout.setContentsMargins(0, 4, 0, 0)
        multi_layout.setSpacing(7)
        multi_layout.addWidget(QLabel("Select one or more layers"))
        self.multi_list = QListWidget()
        self.multi_list.setMinimumHeight(170)
        multi_layout.addWidget(self.multi_list)
        self.stack.addWidget(self.multi_page)
        layout.addWidget(self.stack)

        self.apply_button = QPushButton("OK  ·  Activate Spacebar")
        self.apply_button.setObjectName("primaryButton")
        self.apply_button.clicked.connect(self.activate_mode)
        layout.addWidget(self.apply_button)

        self.status = QLabel("●  Inactive — Spacebar works normally")
        self.status.setObjectName("statusInactive")
        self.status.setWordWrap(True)
        layout.addWidget(self.status)

        self.off_button = QPushButton("Turn Plugin OFF")
        self.off_button.setObjectName("offButton")
        self.off_button.clicked.connect(self.turn_off)
        layout.addWidget(self.off_button)

        note = QLabel("Tip: Press SPACE once to hide and again to restore the previous visibility.")
        note.setObjectName("hint")
        note.setWordWrap(True)
        layout.addWidget(note)
        layout.addStretch(1)

        root.setStyleSheet("""
            QWidget#lvtRoot { background: #f5f7fb; color: #172033; }
            QLabel#heading { font-size: 20px; font-weight: 700; color: #172033; }
            QLabel#subtitle { color: #667085; font-size: 12px; }
            QLabel#sectionLabel { color: #667085; font-size: 10px; font-weight: 700; letter-spacing: 1px; }
            QComboBox, QListWidget { background: white; border: 1px solid #d8deea; border-radius: 8px; padding: 8px; color: #172033; }
            QComboBox { min-height: 22px; }
            QListWidget { padding: 5px; }
            QListWidget::item { padding: 6px; border-radius: 5px; }
            QListWidget::item:selected { background: #e7efff; color: #174ea6; }
            QPushButton { border: 0; border-radius: 8px; padding: 10px 12px; font-weight: 600; }
            QPushButton#primaryButton { background: #2563eb; color: white; }
            QPushButton#primaryButton:hover { background: #1d4ed8; }
            QPushButton#offButton { background: #fff1f0; color: #b42318; border: 1px solid #ffd5d2; }
            QPushButton#offButton:hover { background: #ffe4e1; }
            QLabel#statusInactive { color: #667085; background: #eef1f6; border-radius: 7px; padding: 9px; }
            QLabel#statusActive { color: #067647; background: #e7f7ef; border-radius: 7px; padding: 9px; }
            QLabel#statusHidden { color: #9a6700; background: #fff7df; border-radius: 7px; padding: 9px; }
            QLabel#hint { color: #7b8495; font-size: 11px; }
        """)
        self.dock.setWidget(root)
        self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dock)
        self.dock.visibilityChanged.connect(self._dock_visibility_changed)
        self.project.layersAdded.connect(self.refresh_layers)
        self.project.layersRemoved.connect(self.refresh_layers)
        self.refresh_layers()
        self._mode_changed(0)

    def _mode_changed(self, index):
        if hasattr(self, "stack"):
            self.stack.setCurrentIndex(1 if index == 2 else 0)

    def refresh_layers(self, *args):
        if self.dock is None:
            return
        layers = list(self.project.mapLayers().values())
        current_single = self.single_combo.currentData() if self.single_combo.count() else None
        selected_multi = set()
        for i in range(self.multi_list.count()):
            item = self.multi_list.item(i)
            if item.checkState() == Qt.Checked:
                selected_multi.add(item.data(Qt.UserRole))
        self.single_combo.blockSignals(True)
        self.single_combo.clear()
        for layer in layers:
            self.single_combo.addItem(layer.name(), layer.id())
        if current_single:
            idx = self.single_combo.findData(current_single)
            if idx >= 0:
                self.single_combo.setCurrentIndex(idx)
        self.single_combo.blockSignals(False)
        self.multi_list.clear()
        for layer in layers:
            item = QListWidgetItem(layer.name())
            item.setData(Qt.UserRole, layer.id())
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Checked if layer.id() in selected_multi else Qt.Unchecked)
            self.multi_list.addItem(item)

    def activate_mode(self):
        if self.hidden:
            self._restore_visibility()
        mode = self.mode_combo.currentIndex()
        if mode in (0, 1):
            layer_id = self.single_combo.currentData()
            if not layer_id:
                self._set_status("No layer available. Add a layer first.", "inactive")
                return
            chosen = {layer_id}
        else:
            chosen = set()
            for i in range(self.multi_list.count()):
                item = self.multi_list.item(i)
                if item.checkState() == Qt.Checked:
                    chosen.add(item.data(Qt.UserRole))
            if not chosen:
                self._set_status("Select at least one layer first.", "inactive")
                return
        self.target_ids = chosen
        self.armed = True
        self._install_filter()
        self._set_status("●  ACTIVE — Press SPACE to hide / restore", "active")
        # Return keyboard focus to the map canvas so Spacebar is immediately ready.
        try:
            self.iface.mapCanvas().setFocus(Qt.OtherFocusReason)
        except Exception:
            pass

    def turn_off(self):
        self._deactivate(restore=True)
        self._set_status("●  OFF — Spacebar works normally", "inactive")

    def _deactivate(self, restore=True):
        self.armed = False
        self._remove_filter()
        if restore and self.hidden:
            self._restore_visibility()

    def _install_filter(self):
        app = QApplication.instance()
        if app is None:
            return
        if self.event_filter is None:
            self.event_filter = SpacebarEventFilter(self)
        app.installEventFilter(self.event_filter)

    def _remove_filter(self):
        app = QApplication.instance()
        if app is not None and self.event_filter is not None:
            app.removeEventFilter(self.event_filter)

    def _toggle_visibility(self):
        if not self.armed:
            return
        if not self.hidden:
            root = self.project.layerTreeRoot()
            self.saved_visibility = {}
            for layer in self.project.mapLayers().values():
                node = root.findLayer(layer.id())
                if node is not None:
                    self.saved_visibility[layer.id()] = node.itemVisibilityChecked()
            mode = self.mode_combo.currentIndex()
            for layer_id in list(self.saved_visibility.keys()):
                node = root.findLayer(layer_id)
                if node is None:
                    continue
                if mode == 0:
                    should_hide = layer_id in self.target_ids
                elif mode == 1:
                    should_hide = layer_id not in self.target_ids
                else:
                    should_hide = layer_id in self.target_ids
                if should_hide:
                    node.setItemVisibilityChecked(False)
            self.hidden = True
            self._set_status("●  HIDDEN — Press SPACE to restore", "hidden")
        else:
            self._restore_visibility()

    def _restore_visibility(self):
        root = self.project.layerTreeRoot()
        for layer_id, visible in list(self.saved_visibility.items()):
            node = root.findLayer(layer_id)
            if node is not None:
                node.setItemVisibilityChecked(visible)
        self.saved_visibility = {}
        self.hidden = False
        if self.armed:
            self._set_status("●  ACTIVE — Press SPACE to hide / restore", "active")

    def _set_status(self, message, state):
        if not self.dock:
            return
        self.status.setText(message)
        self.status.setObjectName({"active": "statusActive", "hidden": "statusHidden"}.get(state, "statusInactive"))
        self.status.style().unpolish(self.status)
        self.status.style().polish(self.status)
        self.status.update()

    def _dock_visibility_changed(self, visible):
        if not visible and self.armed:
            self._deactivate(restore=True)
            self._set_status("●  Inactive — panel closed; Spacebar works normally", "inactive")


class SpacebarEventFilter(QObject):
    def __init__(self, plugin):
        super().__init__()
        self.plugin = plugin

    def eventFilter(self, watched, event):
        if not self.plugin.armed or event.type() != QEvent.KeyPress:
            return False
        if event.key() != Qt.Key_Space or event.isAutoRepeat():
            return False
        if event.modifiers() != Qt.NoModifier:
            return False
        app = QApplication.instance()
        focus = app.focusWidget() if app else None
        if focus is None:
            return False
        # Only handle Space while the map canvas has focus. This avoids
        # interfering with layer panels, menus, dialogs, and normal controls.
        canvas = self.plugin.iface.mapCanvas()
        if focus is not canvas and not canvas.isAncestorOf(focus):
            return False
        if isinstance(focus, (QLineEdit, QTextEdit, QPlainTextEdit, QAbstractSpinBox, QAbstractButton, QComboBox, QListWidget)):
            return False
        self.plugin._toggle_visibility()
        event.accept()
        return True
