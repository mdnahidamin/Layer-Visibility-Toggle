def classFactory(iface):
    from .layer_visibility_toggle import LayerVisibilityToggle
    return LayerVisibilityToggle(iface)
